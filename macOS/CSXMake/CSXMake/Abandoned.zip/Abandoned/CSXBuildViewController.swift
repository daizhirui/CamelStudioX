//
//  CSXBuildViewController.swift
//  CSXMake
//
//  Created by Zhirui Dai on 2018/10/1.
//  Copyright © 2018 Zhirui Dai. All rights reserved.
//

import Cocoa

public class CSXBuildViewController: NSViewController {

    public static func initiate() -> CSXBuildViewController {
        return CSXBuildViewController.init(nibName: NSNib.Name("CSXBuild"), bundle: Bundle(for: CSXBuildViewController.self))
    }
    
    
    @IBOutlet weak var scrollView: NSScrollView!
    public let csxMake = CSXMake()
    public let csxTargetManagerViewController = CSXTargetManagerViewController.initiate()
    public var delegate: CSXBuildViewControllerDelegate?
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        self.scrollView.documentView = self.csxTargetManagerViewController.view
//        CSXBuildViewController.addViewToContainer(of: self.csxMake.makeLogViewController, to: self.logView)
//        csxTargetManagerViewController.defaultBuildFolder = URL(fileURLWithPath: "/Users/daizhirui/Development/CamelProject/Hello.cmsproj/build")
    }
    
    override public var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
    
    override public func viewDidAppear() {
        super.viewDidAppear()
        let x = (self.csxTargetManagerViewController.view.frame.width - self.scrollView.frame.width) / 2
        let y = self.csxTargetManagerViewController.view.frame.height - self.scrollView.frame.height
        self.scrollView.contentView.scroll(to: NSPoint(x: x, y: y))
        //        let target = CSXTarget(chipType: .M2, targetType: .Binary,
        //                               cSourceFiles: [URL(fileURLWithPath: "/Users/daizhirui/Development/CamelProject/Hello.cmsproj/Hello.c")],
        //                               cppSourceFiles: [], aSourceFiles: [],
        //                               includeFolders: [], libraries: [TOOLCHAIN_LIB_URL.appendingPathComponent("M2").appendingPathComponent("libstdio.a")],
        //                               buildFolder: URL(fileURLWithPath: "/Users/daizhirui/Development/CamelProject/Hello.cmsproj/build"),
        //                               targetName: "Hello", targetAddress: "10000000", dataAddress: "01000010", rodataAddress: nil)
        //        let messages = self.csxMake.build(target: target)
        //        for message in messages {
        //            message.check()
        //        }
    }
    
    @IBAction public func onBuild(_ sender: NSButton?) {
        guard let target = self.csxTargetManagerViewController.getSelectedTarget() else {
            self.csxMake.printLog("ERROR: No target is selected!\n")
            return
        }
        let messages = self.csxMake.build(target: target)
        for message in messages {
            message.check()
        }
        self.delegate?.csxBuildDidBuildTarget(self)
//        guard let data = try? JSONSerialization.data(withJSONObject: target.dict, options: [.prettyPrinted]) else { return }
//        try? data.write(to: URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("target.json"))
//
//        do {
//            let data = try Data(contentsOf: URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("target.json"))
//            if let dict = try? JSONSerialization.jsonObject(with: data, options: [.allowFragments]) as? [String : Any] {
//                let target = try CSXTarget(dict: dict!)
//            }
//        } catch {
//            print("Fail")
//        }
    }
    
    public static func addViewToContainer(of controller: NSViewController, to superView: NSView) {
        let view = controller.view
        view.translatesAutoresizingMaskIntoConstraints = false
        
        superView.addSubview(view)
        let top = view.topAnchor.constraint(equalTo: superView.topAnchor)
        let bottom = view.bottomAnchor.constraint(equalTo: superView.bottomAnchor)
        let leading = view.leadingAnchor.constraint(equalTo: superView.leadingAnchor)
        let trailing = view.trailingAnchor.constraint(equalTo: superView.trailingAnchor)
        NSLayoutConstraint.activate([top, bottom, leading, trailing])
    }
}
