//
//  CSXBuildViewControllerDelegate.swift
//  CSXMake
//
//  Created by Zhirui Dai on 2018/10/5.
//  Copyright © 2018 Zhirui Dai. All rights reserved.
//

import Foundation

public protocol CSXBuildViewControllerDelegate {
    func csxBuildDidBuildTarget(_ csxBuild: CSXBuildViewController)
}
